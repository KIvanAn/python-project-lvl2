"""Init gendiff package."""
from gendiff.scripts.gendiff import generate_diff
